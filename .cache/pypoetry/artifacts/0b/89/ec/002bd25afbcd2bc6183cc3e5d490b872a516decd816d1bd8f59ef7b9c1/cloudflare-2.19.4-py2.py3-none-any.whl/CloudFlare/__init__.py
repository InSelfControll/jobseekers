""" Cloudflare v4 API"""

__version__ = '2.19.4'

from .cloudflare import CloudFlare

__all__ = ['CloudFlare']
